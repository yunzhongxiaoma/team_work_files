Cute Pets Example App
=====================

Cute Pets Example is a simple app that demonstrates how to use the Google Analytics SDK for Android.
The user enters basic demographic information and ranks pet images by cuteness, and the app sends
corresponding analytics hits. The source code shows how to initialize a Google Analytics
tracker, automatically track screen views, perform background dispatching, and send custom
dimensions and events.

All images are public domain from http://public-domain-image.com.
